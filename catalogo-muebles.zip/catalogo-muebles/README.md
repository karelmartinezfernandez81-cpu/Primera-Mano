# catalogo-muebles

Repositorio para el catálogo de muebles, listo para publicarse en GitHub Pages.

Estructura básica incluida en este ZIP:
- index.html
- camas.html
- muebles-capitoneados.html
- assets/ (styles, js, images, data)

Personaliza las imágenes dentro de `assets/images/` y los estilos en `assets/styles/`.
