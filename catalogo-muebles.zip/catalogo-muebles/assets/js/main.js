console.log('catalogo-muebles: main.js cargado');

function agregarAlCarrito(nombre, precio){
  let carrito = JSON.parse(localStorage.getItem('carrito') || '[]');
  carrito.push({nombre: nombre, precio: Number(precio)});
  localStorage.setItem('carrito', JSON.stringify(carrito));
  alert(nombre + ' agregado al carrito.');
}
